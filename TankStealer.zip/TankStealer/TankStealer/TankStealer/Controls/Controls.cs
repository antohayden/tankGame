﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;


namespace TankStealer.Controls
{
    class Controls
    {
        public Game1.currentState state = new Game1.currentState();
        public GameTime gameTime;
        GamePadState old, current;

        //if in menu controls
        public void MenuState()
        {

        }

        public void inGameState()
        {

        }
    }
}
